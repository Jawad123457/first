<!-- ==========Page Header Section Start Here========== -->
<section class="page-header-section style-1 light-version">
    <div class="container">
        <div class="page-header-content">
            <div class="page-header-inner">
                <div class="page-title">
                    <h2>Super Soldiers 3D  </h2>
                </div>
                <ol class="breadcrumb">
                    <li><a href="index.html">Home</a></li>
                    <li class="active">Item Details</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<!-- ==========Page Header Section Ends Here========== -->


<!-- ==========Item Details Section start Here========== -->
<div class="item-details-section light-version padding-top padding-bottom">
    <div class="container">
        <div class="item-details-wrapper">
            <div class="row g-5">
                <div class="col-lg-6">
                    <div class="item-desc-part">
                        <div class="item-desc-inner">
                            <div class="item-desc-thumb">
                                <img src="{{asset('assets/images/nft-item/blank.png')}}" alt="item-img">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="item-buy-part">
                        <div class="nft-item-title">
                            <h3>Super Soldiers 3D</h3>
                            <div class="share-btn">
                                <div class=" dropstart">
                                    <a class=" dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                        aria-expanded="false" data-bs-offset="25,0">
                                        <i class="icofont-share-alt"></i>
                                    </a>

                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="#"><span>
                                                    <i class="icofont-twitter"></i>
                                                </span> Twitter </a>
                                        </li>
                                        <li><a class="dropdown-item" href="#"><span><i
                                                        class="icofont-telegram"></i></span> Telegram</a></li>
                                        <li><a class="dropdown-item" href="#"><span><i
                                                        class="icofont-envelope"></i></span> Email</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="item-details-countdown">
                            <h4>Ends In:</h4>
                            <ul class="item-countdown-list count-down" data-date="June 05, 2022 21:14:01">
                                <li>
                                    <span class="days">34</span><span class="count-txt">Days</span>
                                </li>
                                <li>
                                    <span class="hours">09</span><span class="count-txt">Hours</span>
                                </li>
                                <li>
                                    <span class="minutes">32</span><span class="count-txt">Mins</span>
                                </li>
                                <li>
                                    <span class="seconds">32</span><span class="count-txt">Secs</span>
                                </li>
                            </ul>
                        </div>
                        <div class="item-price">
                            <h4>Price</h4>
                            <p><span><i class="icofont-coins"></i> 2.29 ETH
                                </span>($ 6,227.15)</p>
                        </div>
                        <div class="buying-btns d-flex flex-wrap">
                            <a href="wallet.html" class="default-btn move-right"><span>Buy Now</span> </a>
                            <a href="wallet.html" class="default-btn move-right"><span>Place a Bid</span> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ==========Item Details Section ends Here========== -->