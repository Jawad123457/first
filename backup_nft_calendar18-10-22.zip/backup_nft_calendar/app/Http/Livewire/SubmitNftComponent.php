<?php

namespace App\Http\Livewire;

use Livewire\Component;

class SubmitNftComponent extends Component
{
    public function render()
    {
        return view('livewire.submit-nft-component')->layout('layouts.base');
    }
}
