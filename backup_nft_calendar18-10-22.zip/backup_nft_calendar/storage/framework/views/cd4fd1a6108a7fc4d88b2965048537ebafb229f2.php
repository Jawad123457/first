<!-- ===============//banner section start here \\================= -->
<section class="banner-section light-version" style="background-image: url(<?php echo e(asset('assets/images/banner/bg-5.jpg')); ?>);">
	<div class="container">
		<div class="banner-wrapper">
			<div class="row align-items-center g-5">
				<div class="col-lg-6">
					<div class="banner-content">
						<h1><span class="theme-color" data-blast="color">NFT Calendar</span>  
							is a Comprehensive list of upcoming, active & Completed <span class="theme-color" data-blast="color">NFT dropsM</span> </h1>
						<p>Digital Marketplace For Crypto Collectibles And Non-Fungible Tokens.
							Buy, Sell, And Discover Exclusive Digital Assets.</p>
						<div class="banner-btns d-flex flex-wrap">
							<a href="<?php echo e(route('submit')); ?>" class="btn theme_button"><span>Submit Drop</span> </a>

						</div>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="nft-slider-wrapper">
						<div class="banner-item-slider">
							<div class="swiper-wrapper">
								<div class="swiper-slide ">
									<div class="nft-item bg-white light-version">
										<div class="nft-inner border-0">
											<!-- nft-bottom part -->
											<div class="nft-item-bottom  bg-white">
												<div class="nft-thumb">
													<img loading="lazy" src="<?php echo e(asset('assets/images/banner/blank.png')); ?>" alt="nft-img">
												</div>
												<div class="nft-content">
													<h4><a href="item-details.html">Future Rocket</a> </h4>
													<div class="price-like d-flex justify-content-between align-items-center">
														<p class="nft-price">Price: <span class="yellow-color">0.34
																ETH</span>
														</p>
														<a href="#" class="nft-like"><i class="icofont-heart"></i>
															230</a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- ===============//banner section end here \\================= -->


<!-- ===============//Category section start here \\================= -->

<!-- ===============//Category section end here \\================= -->



<!-- ===============//auction section start here \\================= -->

<!-- ===============//auction section end here \\================= -->



<!-- ===============//Top Seller section start here \\================= -->

<!-- ===============//Top Seller section end here \\================= -->


<!-- ===============//Exclusive drops section start here \\================= -->
<section class="ex-drop-section padding-bottom">
	<div class="container">
		<div class="section-header style-3">
			<div class="header-shape"><span></span></div>
			<h3>Exclusive NFT Drops</h3>
		</div>
		<div class="section-wrapper">
			<div class="ex-drop-wrapper">
				<div class="row justify-content-center gx-4 gy-3">
					<?php
						 $rand_array = array(1,2,3,4,5,6,7,8);
						 $rand_array = array_rand($rand_array,4);
						//  print_r($rand_array);
					?>
					<?php for($i = 1; $i < 9; $i++): ?>
					
						<div class="col-xl-3 col-lg-4 col-sm-6">
							<div class="nft-item <?php if(in_array($i,$rand_array)): ?> featured_nft <?php endif; ?> light-version">
								<div class="nft-inner">
									<!-- nft-bottom part -->
									<div class="nft-item-bottom nft_drops">
										<div class="nft-thumb">
											<img loading="lazy" src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="nft-img">
										</div>
										<div class="nft-content">
											<h5 class="nft_name"><a href="<?php echo e(route('nftDetails',['slug'=>"Pixal-Boared-Apes"])); ?>">Pixal Boared Apes</a> </h5>
											<span class="nft_short_details">it is a long established fact that a reader will be distracted by the readable .</span>
											
											<div class="social_icon_div d-flex align-items-baseline">
												<i class="fa-brands fa-discord"></i>100
											</div>
											<div class="d-flex text-center mt-3 align-items-baseline nft_social_section_top">
												
												<div class="social_icon_div">
													<i class="fa-brands fa-discord"></i>5.1
												</div>
												<div class="social_icon_div">
													<i class="fa-brands fa-discord"></i>5.1
												</div>
												<div class="social_icon_div">
													<i class="fa-brands fa-discord"></i>1000
												</div>
												<div>
														<?php if(in_array($i,$rand_array)): ?>
														<div class="minting">Minting</div>
														<?php else: ?>
														<div class="mint_date">12 October</div>
														<?php endif; ?>
												</div>

											</div>

													
												
												
												
												
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php endfor; ?>


					
				</div>


			</div>
		</div>
	</div>
</section>
<!-- ===============//Exclusive drops section end here \\================= -->



<!-- ===============//Serach NFT section Start here \\================= -->
<section class="topseller-section padding-bottom">
	<div class="container">
		<div class="section-header style-3">
			<div class="header-shape"><span></span></div>
			<h3>Search Top NFTs</h3>
		</div>
		<div class="section-wrapper">
			<div class="nft-sell-wrapper">
				<div class="row">
					<div class="col-xl-10 col-lg-9 col-12">


						<form class="row g-3">
							<div class="col-6 ">
								<input type="password" class="form-control form-control-lg" id="inputPassword2" placeholder="Search Title Or Description">
							</div>
							<div class="col-auto">
								<div class="dropdown">
										<button class="btn btn-secondary btn-lg dropdown-toggle dropdown-toggle" type="button" id="dropdownMenuButton1"
											data-bs-toggle="dropdown" aria-expanded="false">
											Sort
										</button>
										<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
											<li><a class="dropdown-item" href="#">Action</a></li>
											<li><a class="dropdown-item" href="#">Another action</a></li>
											<li><a class="dropdown-item" href="#">Something else here</a></li>
										</ul>
									</div>
							</div>
							<div class="col-auto">
								<button class="btn btn-danger btn-lg mb-3">Reset <i class="icofont-refresh"></i></button>
							</div>

							<div class="filters col-10">
								<a href="#" class="filter_badges"> <span>2D</span> </a>
								<a href="#" class="filter_badges"> <span>3D</span> </a>
								<a href="#" class="filter_badges"> <span>Ethereum</span> </a>
								<a href="#" class="filter_badges"> <span>Salona</span> </a>
								<a href="#" class="filter_badges"> <span>Free Mint</span> </a>
								<a href="#" class="filter_badges"> <span>Polygon</span> </a>
								<a href="#" class="filter_badges"> <span>Custm.art</span> </a>
								<a href="#" class="filter_badges"> <span>Featured</span> </a>
							</div>
						</form>

						
						
						<?php for($i = 1; $i < 7; $i++): ?>
							<div class="nft-item <?php if(in_array($i,[1,2,3])): ?> featured_nft <?php endif; ?> light-version style-2 mt-2 ">
								<div class="nft-inner">
									<div class="row">
										<div class="col-xl-3 col-md-4 col-12">
											<div class="nft-thumb p-1">
													<img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" class="rounded" alt="nft-img" style="width:100%; height:170px">
												</div>
										</div>
										<div class="col-xl-9 col-md-8 col-12">
											<div class="nft-content">
												<div class="row">
														<div class="col-9 nft_details_section">
															<?php if(in_array($i,[1,2,3])): ?>
																<div class="minting">Minting</div>
															<?php else: ?> 
																<div class="mint_date">12 October</div>
															<?php endif; ?>
														
															<h3 class="nft_name">Pixal Boared Apes</h3>
															<span class="nft_short_details">it is a long established fact that a reader will be distracted by the readable </span>
															<div class="d-flex text-center mt-3 nft_social_section_bottom">
																<div class="social_icon_div">
																	Ethereum <br><i class="fa-brands fa-discord"></i>5.1
																</div>
																<div class="social_icon_div">
																	Twitter <br><i class="fa-brands fa-discord"></i>5.1
																</div>
																<div class="social_icon_div">
																	Discord <br><i class="fa-brands fa-discord"></i>5.1
																</div>
																<div class="social_icon_div">
																	Count <br><i class="fa-brands fa-discord"></i>1000
																</div>
																<div class="social_icon_div">
																	WWW <br><i class="fa-brands fa-discord"></i>
																</div>
																<div class="social_icon_div">
																	Market <br><i class="fa-brands fa-discord"></i>
																</div>
															</div>

														</div>
														<div class="col-3 nft_like_section">
															<?php if(in_array($i,[1,2,3])): ?>
																<div class="featured">
																	<h5>Featured</h5>
																</div>
															<?php endif; ?>

														
															<div class="upvote">
																<span>Upvote</span><br>
																<i class="fa-regular fa-heart"></i>
															</div>
														</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						<?php endfor; ?>
						<div class="text-center mt-3">
							<button class="btn theme_button  " >Load More <i class="icofont-refresh"></i></button>
						</div>
					</div>

					<div class="col-xl-2 col-lg-3 col-12">
						<div class="nft_side_images">
							<img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="">
							<img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="">
							<img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="">
							<img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="">
							<img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="">
							<img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="">
						</div>
					</div>
				
				</div>
			</div>
		</div>
	</div>
</section>

<!-- ===============//Serach NFT section END here \\================= -->

<!-- ===============//blog section start here \\================= -->

<!-- ===============//blog section end here \\================= --><?php /**PATH C:\xampp1\htdocs\nft_calendar\resources\views/livewire/home-component.blade.php ENDPATH**/ ?>