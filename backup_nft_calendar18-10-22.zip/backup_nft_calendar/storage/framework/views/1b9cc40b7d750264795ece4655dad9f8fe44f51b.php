<!-- ==========Page Header Section Start Here========== -->
<section class="page-header-section style-1 light-version">
    <div class="container">
        <div class="page-header-content">
            <div class="page-header-inner">
                <div class="page-title">
                    <h2>Submit Your NFT </h2>
                </div>
                <ol class="breadcrumb">
                    <li><a href="index.html">Home</a></li>
                    <li class="active">Submit</li>
                </ol>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp1\htdocs\nft_calendar\resources\views/livewire/submit-nft-component.blade.php ENDPATH**/ ?>