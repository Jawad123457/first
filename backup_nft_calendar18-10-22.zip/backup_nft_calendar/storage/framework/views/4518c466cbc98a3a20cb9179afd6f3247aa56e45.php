<!-- ===============//banner section start here \\================= -->
<section class="banner-section light-version" style="background-image: url(<?php echo e(asset('assets/images/banner/blank.pngng')); ?>);">
	<div class="container">
		<div class="banner-wrapper">
			<div class="row align-items-center g-5">
				<div class="col-lg-6">
					<div class="banner-content">
						<h1><span class="theme-color" data-blast="color">Discover</span> Collect <br>
							And Sell <span class="theme-color" data-blast="color">NFT</span> Assets</h1>
						<p>Digital Marketplace For Crypto Collectibles And Non-Fungible Tokens.
							Buy, Sell, And Discover Exclusive Digital Assets.</p>
						<div class="banner-btns d-flex flex-wrap">
							<a data-blast="bgColor" href="explore.html" class="default-btn move-top"><span>Explore</span> </a>
							<a href="signin.html" class="default-btn move-right"><span>Create</span> </a>

						</div>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="nft-slider-wrapper">
						<div class="banner-item-slider">
							<div class="swiper-wrapper">
								<div class="swiper-slide">
									<div class="nft-item light-version">
										<div class="nft-inner">
											<!-- nft top part -->
											<div class="nft-item-top d-flex justify-content-between align-items-center">
												<div class="author-part">
													<ul class="author-list d-flex">
														<li class="single-author d-flex align-items-center">
															<a href="author.html" class="veryfied"><img loading="lazy"
																	src="<?php echo e(asset('assets/images/seller/avtar.png')); ?>" alt="author-img"></a>
															<h6><a href="author.html">rasselmrh</a></h6>
														</li>
													</ul>
												</div>
												<div class="more-part">
													<div class=" dropstart">
														<a class=" dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
															aria-expanded="false" data-bs-offset="25,0">
															<i class="icofont-flikr"></i>
														</a>

														<ul class="dropdown-menu">
															<li><a class="dropdown-item" href="#"><span>
																		<i class="icofont-warning"></i>
																	</span> Report </a>
															</li>
															<li><a class="dropdown-item" href="#"><span><i class="icofont-reply"></i></span>
																	Share</a></li>
														</ul>
													</div>
												</div>
											</div>
											<!-- nft-bottom part -->
											<div class="nft-item-bottom">
												<div class="nft-thumb">
													<img loading="lazy" src="<?php echo e(asset('assets/images/banner/blank.png')); ?>" alt="nft-img">

													<!-- nft countdwon -->
													<!-- <ul class="nft-countdown count-down" data-date="July 05, 2022 21:14:01">
															<li>
																	<span class="days">34</span><span class="count-txt">D</span>
															</li>
															<li>
																	<span class="hours">09</span><span class="count-txt">H</span>
															</li>
															<li>
																	<span class="minutes">32</span><span class="count-txt">M</span>
															</li>
															<li>
																	<span class="seconds">32</span><span class="count-txt">S</span>
															</li>
													</ul> -->
												</div>
												<div class="nft-content">
													<h4><a href="item-details.html">Black Cat </a> </h4>
													<div class="price-like d-flex justify-content-between align-items-center">
														<p class="nft-price">Price: <span class="yellow-color">0.34
																ETH</span>
														</p>
														<a href="#" class="nft-like"><i class="icofont-heart"></i>
															230</a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="nft-item light-version">
										<div class="nft-inner">
											<!-- nft top part -->
											<div class="nft-item-top d-flex justify-content-between align-items-center">
												<div class="author-part">
													<ul class="author-list d-flex">
														<li class="single-author d-flex align-items-center">
															<a href="author.html" class="veryfied"><img loading="lazy"
																	src="<?php echo e(asset('assets/images/seller/avtar.png')); ?>" alt="author-img"></a>
															<h6><a href="author.html">Gucci Lucas</a></h6>
														</li>
													</ul>
												</div>
												<div class="more-part">
													<div class=" dropstart">
														<a class=" dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
															aria-expanded="false" data-bs-offset="25,0">
															<i class="icofont-flikr"></i>
														</a>

														<ul class="dropdown-menu">
															<li><a class="dropdown-item" href="#"><span>
																		<i class="icofont-warning"></i>
																	</span> Report </a>
															</li>
															<li><a class="dropdown-item" href="#"><span><i class="icofont-reply"></i></span>
																	Share</a></li>
														</ul>
													</div>
												</div>
											</div>
											<!-- nft-bottom part -->
											<div class="nft-item-bottom">
												<div class="nft-thumb">
													<img loading="lazy" src="<?php echo e(asset('assets/images/banner/blank.png')); ?>" alt="nft-img">

													<!-- nft countdwon -->
													<!-- <ul class="nft-countdown count-down" data-date="July 05, 2022 21:14:01">
															<li>
																	<span class="days">34</span><span class="count-txt">D</span>
															</li>
															<li>
																	<span class="hours">09</span><span class="count-txt">H</span>
															</li>
															<li>
																	<span class="minutes">32</span><span class="count-txt">M</span>
															</li>
															<li>
																	<span class="seconds">32</span><span class="count-txt">S</span>
															</li>
													</ul> -->
												</div>
												<div class="nft-content">
													<h4><a href="item-details.html">EUPHORIA de</a> </h4>
													<div class="price-like d-flex justify-content-between align-items-center">
														<p class="nft-price">Price: <span class="yellow-color">0.34
																ETH</span>
														</p>
														<a href="#" class="nft-like"><i class="icofont-heart"></i>
															230</a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="nft-item light-version">
										<div class="nft-inner">
											<!-- nft top part -->
											<div class="nft-item-top d-flex justify-content-between align-items-center">
												<div class="author-part">
													<ul class="author-list d-flex">
														<li class="single-author d-flex align-items-center">
															<a href="author.html" class="veryfied"><img loading="lazy"
																	src="<?php echo e(asset('assets/images/seller/avtar.png')); ?>" alt="author-img"></a>
															<h6><a href="author.html">lcus x3</a></h6>
														</li>
													</ul>
												</div>
												<div class="more-part">
													<div class=" dropstart">
														<a class=" dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
															aria-expanded="false" data-bs-offset="25,0">
															<i class="icofont-flikr"></i>
														</a>

														<ul class="dropdown-menu">
															<li><a class="dropdown-item" href="#"><span>
																		<i class="icofont-warning"></i>
																	</span> Report </a>
															</li>
															<li><a class="dropdown-item" href="#"><span><i class="icofont-reply"></i></span>
																	Share</a></li>
														</ul>
													</div>
												</div>
											</div>
											<!-- nft-bottom part -->
											<div class="nft-item-bottom">
												<div class="nft-thumb">
													<img loading="lazy" src="<?php echo e(asset('assets/images/banner/blank.png')); ?>" alt="nft-img">

													<!-- nft countdwon -->
													<!-- <ul class="nft-countdown count-down" data-date="July 05, 2022 21:14:01">
															<li>
																	<span class="days">34</span><span class="count-txt">D</span>
															</li>
															<li>
																	<span class="hours">09</span><span class="count-txt">H</span>
															</li>
															<li>
																	<span class="minutes">32</span><span class="count-txt">M</span>
															</li>
															<li>
																	<span class="seconds">32</span><span class="count-txt">S</span>
															</li>
													</ul> -->
												</div>
												<div class="nft-content">
													<h4><a href="item-details.html">Silly C4T de</a> </h4>
													<div class="price-like d-flex justify-content-between align-items-center">
														<p class="nft-price">Price: <span class="yellow-color">0.34
																ETH</span>
														</p>
														<a href="#" class="nft-like"><i class="icofont-heart"></i>
															230</a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="swiper-slide">
									<div class="nft-item light-version">
										<div class="nft-inner">
											<!-- nft top part -->
											<div class="nft-item-top d-flex justify-content-between align-items-center">
												<div class="author-part">
													<ul class="author-list d-flex">
														<li class="single-author d-flex align-items-center">
															<a href="author.html" class="veryfied"><img loading="lazy"
																	src="<?php echo e(asset('assets/images/seller/avtar.png')); ?>" alt="author-img"></a>
															<h6><a href="author.html">Imo35 ucas</a></h6>
														</li>
													</ul>
												</div>
												<div class="more-part">
													<div class=" dropstart">
														<a class=" dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
															aria-expanded="false" data-bs-offset="25,0">
															<i class="icofont-flikr"></i>
														</a>

														<ul class="dropdown-menu">
															<li><a class="dropdown-item" href="#"><span>
																		<i class="icofont-warning"></i>
																	</span> Report </a>
															</li>
															<li><a class="dropdown-item" href="#"><span><i class="icofont-reply"></i></span>
																	Share</a></li>
														</ul>
													</div>
												</div>
											</div>
											<!-- nft-bottom part -->
											<div class="nft-item-bottom">
												<div class="nft-thumb">
													<img loading="lazy" src="<?php echo e(asset('assets/images/banner/blank.png')); ?>" alt="nft-img">

													<!-- nft countdwon -->
													<!-- <ul class="nft-countdown count-down" data-date="July 05, 2022 21:14:01">
															<li>
																	<span class="days">34</span><span class="count-txt">D</span>
															</li>
															<li>
																	<span class="hours">09</span><span class="count-txt">H</span>
															</li>
															<li>
																	<span class="minutes">32</span><span class="count-txt">M</span>
															</li>
															<li>
																	<span class="seconds">32</span><span class="count-txt">S</span>
															</li>
													</ul> -->
												</div>
												<div class="nft-content">
													<h4><a href="item-details.html">Future Rocket</a> </h4>
													<div class="price-like d-flex justify-content-between align-items-center">
														<p class="nft-price">Price: <span class="yellow-color">0.34
																ETH</span>
														</p>
														<a href="#" class="nft-like"><i class="icofont-heart"></i>
															230</a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- ===============//banner section end here \\================= -->


<!-- ===============//Category section start here \\================= -->

<!-- ===============//Category section end here \\================= -->



<!-- ===============//auction section start here \\================= -->

<!-- ===============//auction section end here \\================= -->



<!-- ===============//Top Seller section start here \\================= -->

<!-- ===============//Top Seller section end here \\================= -->


<!-- ===============//Exclusive drops section start here \\================= -->
<section class="ex-drop-section padding-bottom">
	<div class="container">
		<div class="section-header style-3">
			<div class="header-shape"><span></span></div>
			<h3>Exclusive NFT Drops</h3>
		</div>
		<div class="section-wrapper">
			<div class="ex-drop-wrapper">
				<div class="row justify-content-center gx-4 gy-3">
					<?php for($i = 1; $i < 9; $i++): ?>
						<div class="col-xl-3 col-lg-4 col-sm-6">
							<div class="nft-item light-version">
								<div class="nft-inner">
									<!-- nft top part -->
									<div class="nft-item-top d-flex justify-content-between align-items-center">
										<div class="author-part">
											<ul class="author-list d-flex">
												<li class="single-author d-flex align-items-center">
													<a href="author.html" class="veryfied"><img loading="lazy" src="<?php echo e(asset('assets/images/seller/avtar.png')); ?>"
															alt="author-img"></a>
													<h6><a href="author.html">Gucci Lucas</a></h6>
												</li>
											</ul>
										</div>
										<div class="more-part">
											<div class=" dropstart">
												<a class=" dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"
													data-bs-offset="25,0">
													<i class="icofont-flikr"></i>
												</a>

												<ul class="dropdown-menu">
													<li><a class="dropdown-item" href="#"><span>
																<i class="icofont-warning"></i>
															</span> Report </a>
													</li>
													<li><a class="dropdown-item" href="#"><span><i class="icofont-reply"></i></span> Share</a></li>
												</ul>
											</div>
										</div>
									</div>
									<!-- nft-bottom part -->
									<div class="nft-item-bottom nft_drops">
										<div class="nft-thumb">
											<img loading="lazy" src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="nft-img">

											<!-- nft countdwon -->
											<ul class="nft-countdown count-down" data-date="December 05, 2022 21:14:01">
													<li>
															<span class="days">54</span><span class="count-txt">D</span>
													</li>
													<li>
															<span class="hours">0</span><span class="count-txt">H</span>
													</li>
													<li>
															<span class="minutes">0</span><span class="count-txt">M</span>
													</li>
													<li>
															<span class="seconds">00</span><span class="count-txt">S</span>
													</li>
											</ul> 
										</div>
										<div class="nft-content">
											<h4><a href="<?php echo e(route('nftDetails',['slug'=>"EUP-HORIA-de"])); ?>">EUPHORIA de</a> </h4>
											<div class="price-like d-flex justify-content-between align-items-center">
												<p class="nft-price">Price: <span class="yellow-color">0.34 ETH</span>
												</p>
												<a href="#" class="nft-like"><i class="icofont-heart"></i>
													230</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php endfor; ?>


					
				</div>


			</div>
		</div>
	</div>
</section>
<!-- ===============//Exclusive drops section end here \\================= -->



<!-- ===============//blog section start here \\================= -->
<section class="blog-section pb-120">
	<div class="container">
		<div class="section-header style-3">
			<div class="header-shape"><span></span></div>
			<h3>Our Blog Posts</h3>
		</div>
		<div class="section-wrapper">

			<div class="blog-wrapper">
				<div class="row justify-content-center gx-4 gy-2">
					<div class="col-lg-4 col-sm-6">
						<div class="nft-item light-version blog-item">
							<div class="nft-inner">
								<div class="nft-thumb">
									<img src="<?php echo e(asset('assets/images/nft-item/blog/blank.png')); ?>" alt="blog-img">
								</div>
								<div class="nft-content">
									<div class="author-details">
										<h4><a href="blog-single.html">The Rise of the Non Fungible Tokens
												(NFTs)</a> </h4>
										<div class="meta-info">
											<p><span><i class="icofont-ui-calendar" data-blast="color"></i></span>July 20 2022
											</p>
											<p><span><i class="icofont-user" data-blast="color"></i></span>Jhon doe
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-sm-6">
						<div class="nft-item light-version blog-item">
							<div class="nft-inner">
								<div class="nft-thumb">
									<img src="<?php echo e(asset('assets/images/nft-item/blog/blank.png')); ?>" alt="blog-img">
								</div>
								<div class="nft-content">
									<div class="author-details">
										<h4><a href="blog-single.html"> Top 5 Most Popular NFT Games in 2022</a>
										</h4>
										<div class="meta-info">
											<p><span><i class="icofont-ui-calendar" data-blast="color"></i></span>July 20 2022
											</p>
											<p><span><i class="icofont-user" data-blast="color"></i></span>Rassel H.
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-sm-6">
						<div class="nft-item light-version blog-item">
							<div class="nft-inner">
								<div class="nft-thumb">
									<img src="<?php echo e(asset('assets/images/nft-item/blog/blank.png')); ?>" alt="blog-img">
								</div>
								<div class="nft-content">
									<div class="author-details">
										<h4><a href="blog-single.html">Best NFT Selling Marketplace website</a>
										</h4>
										<div class="meta-info">
											<p><span><i class="icofont-ui-calendar" data-blast="color"></i></span>July 20 2022
											</p>
											<p><span><i class="icofont-user" data-blast="color"></i></span>Alex zym
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- ===============//blog section end here \\================= --><?php /**PATH C:\xampp1\htdocs\nft_calendar\resources\views\livewire\home-component.blade.php ENDPATH**/ ?>