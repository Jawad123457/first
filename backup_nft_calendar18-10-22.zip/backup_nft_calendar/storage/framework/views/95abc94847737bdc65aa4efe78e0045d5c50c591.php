<!-- ==========Page Header Section Start Here========== -->
<section class="page-header-section style-1 light-version">
    <div class="container">
        <div class="page-header-content">
            <div class="page-header-inner">
                <div class="page-title">
                    <h2>Blog Single Page </h2>
                </div>
                <ol class="breadcrumb">
                    <li><a href="index.html">Home</a></li>
                    <li class="active">Blog Single </li>
                </ol>
            </div>
        </div>
    </div>
</section>
<!-- ==========Page Header Section Ends Here========== -->


<!-- ==========Blog Section start Here========== -->
<section class="blog-section light-version padding-top padding-bottom">
    <div class="container">
        <div class="main-blog">
            <div class="row g-5">
                <div class="col-xl-9 mt-0 col-12">
                    <div class="blog-wrapper">
                        <div class="post-item">
                            <h3>A wonderf serenity has taken poesion of my entire souin like these sweet
                                mornins</h3>
                                <hr>
                                <div class="row">
                                    <di class="col-lg-8 col-md-4 col-sm-6">
                                        <h4 class="blog_writer_details">INSIGHT Report <br> AUGUST CHAPTER</h4>
                                    </di>
                                    <di class="col-lg-2 col-md-4 col-sm-6">
                                        <h4 class="blog_writer_details">Writer <br>dwinawan</h4>
                                    </di>
                                    <di class="col-lg-2 col-md-4 col-sm-6">
                                        <h4 class="blog_writer_details">Date <br> AUGUST 11, 2022</h4>
                                    </di>
                                </div>
                            <div class="post-item-inner">
                                <div class="post-thumb">
                                    <img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="blog">
                                </div>
                                <div class="post-content">
                                    <span class="meta">By <a href="#">Admin</a> March 24, 2022</span>
                                    <p>A wonderf serenity has taken poesion of my entire souin like these sweet
                                        mornins sprin which enjy with my whole hear I am alone and feel the charm
                                        of existen spot which was creatie For the blisse of souls like mineingi am
                                        so
                                        happy my dear friend, so absoribed in the exquisite sense tranquilera
                                        existence, that I neglect my talentsri I should bye incapable of drawin and
                                        sinle stroke A wonderful serenity has taken possession of my entire souing
                                        like these sweet mornins sprng enjoy with mye whole heart. I am alone, and
                                        feel the charm of existthis spot which was creatied the bliss of souls like
                                        mineingi am so happy my dear friend, so absoribed in the exquisite sense
                                        tranquil existnce, dt I neglect my talentsri I should bye incapable of
                                        drawin and single stroke enjoy with my whole hrt. I am alone, and feel the
                                        charm of existencethis spot which was For the bliss of souls like mineingis
                                        am so happy my dear friend, so absoribed in the exquisite sense tranquil
                                        existence, that I neglects my talentsri I should bye incapable of drawing
                                        and
                                        single the present moment; and yet If feel that I never was a greater artst

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-12">
                    <aside>

                        <div class="widget light-version widget-post">
                            <div class="widget-header">
                                <h5 class="title">Most Popular Post</h5>
                            </div>
                            <ul class="widget-wrapper">
                                <li class="d-flex flex-wrap justify-content-between">
                                    <div class="post-thumb">
                                        <a href="blog-single.html"><img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="post-img"></a>
                                    </div>
                                    <div class="post-content">
                                        <a href="blog-single.html">
                                            <h6>Poor People’s Campaign Our Resources</h6>
                                        </a>
                                        <p>July 23,2022</p>
                                    </div>
                                </li>
                                <li class="d-flex flex-wrap justify-content-between">
                                    <div class="post-thumb">
                                        <a href="blog-single.html"><img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="post-img"></a>
                                    </div>
                                    <div class="post-content">
                                        <a href="blog-single.html">
                                            <h6>Boosting Social For NGO And Charities </h6>
                                        </a>
                                        <p>July 23,2022</p>
                                    </div>
                                </li>
                                <li class="d-flex flex-wrap justify-content-between">
                                    <div class="post-thumb">
                                        <a href="blog-single.html"><img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="post-img"></a>
                                    </div>
                                    <div class="post-content">
                                        <a href="blog-single.html">
                                            <h6>Poor People’s Campaign Our Resources</h6>
                                        </a>
                                        <p>July 23,2022</p>
                                    </div>
                                </li>
                            </ul>
                        </div>

                       <div class="widget bg-white light-version widget-tags">
                        <div class="widget-header">
                            <h5 class="title">Our Popular Tags</h5>
                        </div>
                        <ul class="widget-wrapper">
                            <li><a href="#" class="border_radius_50 box_shadow">audiojungle</a></li>
                            <li><a href="#" class="border_radius_50 box_shadow active">audiojungle</a></li>
                            <li><a href="#" class="border_radius_50 box_shadow">audiojungle</a></li>
                            <li><a href="#" class="border_radius_50 box_shadow">audiojungle</a></li>
                            <li><a href="#" class="border_radius_50 box_shadow">audiojungle</a></li>
                            <li><a href="#" class="border_radius_50 box_shadow">audiojungle</a></li>
                            <li><a href="#" class="border_radius_50 box_shadow">audiojungle</a></li>
                            <li><a href="#" class="border_radius_50 box_shadow">audiojungle</a></li>
                        </ul>
                    </div>


                    </aside>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ==========Blog Section ends Here========== --><?php /**PATH C:\xampp1\htdocs\nft_calendar\resources\views/livewire/blog-details-component.blade.php ENDPATH**/ ?>