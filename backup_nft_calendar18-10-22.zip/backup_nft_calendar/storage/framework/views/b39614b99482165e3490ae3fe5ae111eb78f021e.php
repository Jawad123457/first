<!-- ==========Page Header Section Start Here========== -->
<section class="page-header-section style-1 light-version">
    <div class="container">
        <div class="page-header-content">
            <div class="page-header-inner">
                <div class="page-title">
                    <h2>Blog </h2>
                </div>
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="active">Blog </li>
                </ol>
            </div>
        </div>
    </div>
</section>
<!-- ==========Page Header Section Ends Here========== -->


<!-- ==========Blog Section start Here========== -->
<section class="blog-section light-version padding-top padding-bottom">
    <div class="container">
        <div class="main-blog">
            <div class="row g-5">
                <div class="col-xl-12 col-12">
                    <div class="blog-wrapper">
                        <div class="row justify-content-center gx-4 gy-3">
                            <?php for($i = 1; $i <= 12; $i++): ?>
                            <div class="col-lg-4 col-sm-6">
                                <div class="nft-item blog-item light-version">
                                    <div class="nft-inner">
                                        <div class="nft-thumb">
                                            <img src="<?php echo e(asset('assets/images/nft-item/blank.png')); ?>" alt="blank.png">
                                        </div>
                                        <div class="nft-content">
                                            <div class="author-details">
                                                <h4><a href="<?php echo e(route('blogDetails',['slug'=>"Non-Fungible-Tokens"])); ?>">The Rise of the Non Fungible Tokens (NFTs)</a> </h4>
                                                <div class="meta-info">
                                                    <p class="date"><span><i class="icofont-ui-calendar"></i></span>July 20, 2022
                                                    </p>

                                                    <p><span><i class="icofont-user"></i></span>Jhon doe</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <div class="paginations light-version">
                        <ul class="lab-ul d-flex flex-wrap justify-content-center mb-1">
                            <li>
                                <a href="#"><i class="icofont-rounded-double-left"></i></a>
                            </li>
                            <li>
                                <a href="#">1</a>
                            </li>
                            <li class="d-none d-sm-block">
                                <a href="#">2</a>
                            </li>
                            <li>
                                <a href="#">...</a>
                            </li>
                            <li class="d-none d-sm-block">
                                <a href="#">4</a>
                            </li>
                            <li>
                                <a href="#">5</a>
                            </li>
                            <li>
                                <a href="#"><i class="icofont-rounded-double-right"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
               
            </div>
        </div>
    </div>
</section>
<!-- ==========Blog Section ends Here========== --><?php /**PATH C:\xampp1\htdocs\nft_calendar\resources\views\livewire\blog-component.blade.php ENDPATH**/ ?>