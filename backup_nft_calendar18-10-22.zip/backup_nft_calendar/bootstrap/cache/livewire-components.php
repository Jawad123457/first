<?php return array (
  'blog-component' => 'App\\Http\\Livewire\\BlogComponent',
  'blog-details-component' => 'App\\Http\\Livewire\\BlogDetailsComponent',
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
  'nft-details-component' => 'App\\Http\\Livewire\\NftDetailsComponent',
  'submit-nft-component' => 'App\\Http\\Livewire\\SubmitNftComponent',
);